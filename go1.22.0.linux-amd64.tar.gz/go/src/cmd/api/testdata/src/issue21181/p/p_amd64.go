package p

import "indirect"

var in = []algo{
	{indirect.F},
}
